# Tugas Besar 3 - IF2211 - Strategi Algoritma

![flake8](https://github.com/Lock1/Stima3-IF2211/actions/workflows/pylinter.yml/badge.svg)

pip install flask
Requirements:
 - python 3.7
 - type "pip install flask" in cmd
